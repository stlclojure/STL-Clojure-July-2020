using UnityEngine;
using UnityEngine.EventSystems;
using clojure.lang;

public class StartHook : ArcadiaBehaviour
{
  public void Start()
  {
      RunFunctions();
  }
}