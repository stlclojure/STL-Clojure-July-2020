using UnityEngine;
using UnityEngine.EventSystems;
using clojure.lang;

public class OnMouseUpAsButtonHook : ArcadiaBehaviour
{
  public void OnMouseUpAsButton()
  {
      RunFunctions();
  }
}