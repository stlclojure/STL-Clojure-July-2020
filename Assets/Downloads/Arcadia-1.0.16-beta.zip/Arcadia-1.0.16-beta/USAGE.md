Arcadia's usage is described in [the project wiki](https://github.com/arcadia-unity/Arcadia/wiki).
